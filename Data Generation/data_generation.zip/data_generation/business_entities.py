import time
from datetime import datetime
import pandas as pd
import numpy as np
import random
from mimesis import Person
from mimesis import Address
from mimesis import Finance
from mimesis import Generic
from mimesis import Datetime
from data_generation.constants import ENTITY_TYPES
from data_generation.utils import fetch_business_name

from data_generation.harvesting import HarvestingData
from data_generation.cooling import CoolingData
from data_generation.shipping import ShippingData
from data_generation.transformation import TransformationData
from data_generation.land_based_receiver import LandBasedReceiverData
from data_generation.packaging import PackagingData
from data_generation.receiving import ReceivingData


class BusinessEntitiesData:

    def __init__(self):
        self.person = Person('en')
        self.address = Address('en')
        self.finance = Finance('en')
        self.generic = Generic('en')
        self.datetime = Datetime('en')

        self.entities = ENTITY_TYPES
    
    def generate_synthetic_data(self, sample_size):
        synthetic_data = []
        for row in range(sample_size):
            business_type = random.choice(ENTITY_TYPES)
            data = {
                'businessType': business_type,
                'businessName': fetch_business_name(business_type),
                'primaryPhone': self.person.telephone(mask='##########'),
                'streetAddress': self.address.address(),
                'city': self.address.city(),
                'state': self.address.state(abbr=True),
                'zip': self.address.zip_code(),
                'companyPrefix': f"{random.choice(['06','07','08','09','10','11','12','13'])}{random.randint(10000, 99999)}",
                'sizeWeight': round(random.uniform(0.05, 0.8), 2),
            }
            # print(data)

            synthetic_data.append(data)
        business_entities_df = pd.DataFrame(synthetic_data)
        endings = np.random.randint(10000,99999,size=len(business_entities_df))
        glnList = business_entities_df['companyPrefix'].values
        business_entities_df['gln']=[prefix + '.' + str(ending) for prefix,ending in zip(glnList,endings)]

        return business_entities_df
    
    @staticmethod
    def farm_function(ftl_item, sc, entities, previous_cte, index):
        farm = entities.iloc[index]
        packaged_type = sc[sc.index('farm') + 1]

        try:
            next_entity = entities.iloc[index+1]

        except:
            next_entity = farm

        #Initialize the CTEs for the farm
        ctes = {}

        #Determine what the next entity is for the KDEs that happen on the farm
        if packaged_type == 'fieldPacked':
            ctes['harvesting'] = HarvestingData.harvesting_cte(ftl_item, farm, farm)
            ctes['cooling'] = CoolingData.cooling_cte(ctes['harvesting'], ftl_item, farm, farm)
            ctes['initialPackaging'] = PackagingData.packaging_cte(ctes['harvesting'],ctes['cooling'],ftl_item,farm)
            ctes['shipping'] = ShippingData.shipping_cte(ctes['initialPackaging'],next_entity,farm)
        elif packaged_type == 'packaging':
            ctes['harvesting'] = HarvestingData.harvesting_cte(ftl_item, farm, next_entity)

        return ctes

    @staticmethod
    def initial_fish_function(ftl_item, sc, entities, previous_cte, index):
        category = ftl_item.Supply_Chain.values[0]

        ctes={}
        #Aquaculture route
        if category == 'Aquaculture':
            facility = entities.iloc[index]
            next_entity=facility
            ctes['harvesting'] = HarvestingData.harvesting_cte(ftl_item, facility, next_entity)
            ctes['cooling'] = CoolingData.cooling_cte(ctes['harvesting'], ftl_item, facility, next_entity)
            ctes['initialPackaging'] = PackagingData.packaging_cte(ctes['harvesting'],ctes['cooling'],ftl_item,facility)

        #Wild Caught Route
        elif category =='Caught':
            facility = entities.iloc[index]
            ctes['firstLandBasedReceiving'] = LandBasedReceiverData.first_land_based_receiver_cte(ftl_item, facility)

        #Ship to the next entity
        last_cte = list(ctes.keys())[-1]
        ctes['shipping'] = ShippingData.shipping_cte(ctes[last_cte],next_entity=entities.iloc[index+1],facility=facility)

        return ctes 

    @staticmethod
    def processing_plant_function(ftl_item, sc, entities, previous_cte, index):

        facility = entities.iloc[index]
        try:
            next_entity = entities.iloc[index+1]
            kill = 0
        except:
            kill = 1

        # Initialize the CTEs for the processing plant
        ctes = {}

        #The path if it is a created product and the first step in the supply chain
        if index == 0:
            ctes['transformation'] = TransformationData.transformation_cte(previous_cte,ftl_item,facility)

        #The path if it is not the first step in the supply chain
        else:

            ctes['receiving'] = ReceivingData.receiving_cte(previous_cte, facility)
            ctes['transformation'] = TransformationData.transformation_cte(ctes['receiving'], ftl_item, facility)

        #Determine if a kill step had happened, if not proceed
        if kill == 0:
            ctes['shipping'] = ShippingData.shipping_cte(ctes['transformation'], next_entity, facility)
        
        return ctes

    @staticmethod
    def coolingpacking_function(ftl_item, sc, entities, previous_cte, index):
        # Initialize the CTEs for the offsite cooling and packing facility
        facility = entities.iloc[index]

        try:
            next_entity = entities.iloc[index+1]
            kill = 0
        except:
            next_entity = 0
            kill = 1

        ctes = {}

        ctes['cooling'] = CoolingData.cooling_cte(previous_cte, ftl_item, facility, facility)
        ctes['initialPackaging'] = PackagingData.packaging_cte(previous_cte,ctes['cooling'],ftl_item, facility)

        if kill == 0:
            ctes['shipping'] = ShippingData.shipping_cte(ctes['initialPackaging'], next_entity=next_entity, facility=facility)

        return ctes

    @staticmethod
    def distributor_function(ftl_item, sc, entities, previous_cte, index):
        facility = entities.iloc[index]
        next_entity = entities.iloc[index+1]

        # Initialize the CTEs for the processing plant
        ctes = {}

        ctes['receiving'] = ReceivingData.receiving_cte(previous_cte, facility)

        ctes['shipping'] = ShippingData.shipping_cte(ctes['receiving'], next_entity, facility)

        return ctes

    @staticmethod
    def wholesaler_function(ftl_item, sc, entities, previous_cte, index):
        facility = entities.iloc[index]

        try:
            next_entity = entities.iloc[index+1]
            kill = 0

        except:
            kill = 1

        # Initialize the CTEs for the processing plant
        ctes = {}

        ctes['receiving'] = ReceivingData.receiving_cte(previous_cte, facility)

        #Determine if there is going to be a transformation or not
        if random.randint(0,100) > 50:
            ctes['transformation'] = TransformationData.transformation_cte(ctes['receiving'], ftl_item, facility)

        if kill == 0:
            last_cte = list(ctes.keys())[-1]
            ctes['shipping'] = ShippingData.shipping_cte(ctes[last_cte], next_entity, facility)

        return ctes

    @staticmethod
    def grocery_function(ftl_item, sc, entities, previous_cte, index):
        facility = entities.iloc[index]

        # Initialize the CTEs for the processing plant
        ctes = {}

        ctes['receiving'] = ReceivingData.receiving_cte(previous_cte, facility)

        #Determine if there is going to be a transformation or not
        if random.randint(0,100) < 10:
            ctes['transformation'] = TransformationData.transformation_cte(ctes['receiving'], ftl_item, facility)

        return ctes

    @staticmethod
    def restaurant_function(ftl_item, sc, entities, previous_cte, index):
        facility = entities.iloc[index]

        # Initialize the CTEs for the processing plant
        ctes = {}

        ctes['receiving'] = ReceivingData.receiving_cte(previous_cte, facility)

        #Determine if there is going to be a transformation or not
        if random.randint(0,100) > 95:
            ctes['transformation'] = TransformationData.transformation_cte(ctes['receiving'], ftl_item, facility)

        return ctes

    @staticmethod
    def grocery_no_transform_function(ftl_item, sc, entities, previous_cte, index):
        facility = entities.iloc[index]

        # Initialize the CTEs for the processing plant
        ctes = {}

        ctes['receiving'] = ReceivingData.receiving_cte(previous_cte, facility)

        return ctes

