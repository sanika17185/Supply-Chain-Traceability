import time
import random
from datetime import datetime

class CoolingData:

    def __init__(self):
        pass

    @staticmethod
    def cooling_cte(harvesting_info, ftl_item, facility, next_entity):
    
        data_submitter = facility.businessName
        food_name = ftl_item.Food.values[0]
        quantity = harvesting_info['quantity']
        recipient = next_entity.businessName
        unit_of_measure = harvesting_info['unitOfMeasure']
        farm_name = harvesting_info['dataSubmitter']
        cooler_location = facility.businessName
        date_cooled = harvesting_info['cteDate']
        phone_number = facility.primaryPhone
        contaminated = harvesting_info['contaminated']

        if contaminated == 0:
            if random.randint(0,6000) == 1:
                contaminated = 1
        
        #Need to add location description of farm where it was harvested
        cooling_info = {
            'dataSubmitter': data_submitter,
            'recipient' : recipient,
            'commodity': food_name,
            'quantity' : quantity,
            'unitOfMeasure' : unit_of_measure,
            'coolerLocation' : cooler_location,
            'cteDate' : date_cooled,
            'harvesterName' : farm_name,
            'phoneNumber' : phone_number,
            'contaminated' : contaminated, 
            'gtin':harvesting_info['gtin'],
            'sgln':harvesting_info['sgln'],
            'pgln':facility.gln,
            'eventID':facility.gln+'.'+str(random.randint(1000000, 9999999)),
            'parentID':harvesting_info['eventID']
        }

        return cooling_info
