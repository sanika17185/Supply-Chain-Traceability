import time
import random
import string
from datetime import datetime, timedelta
from typing import Text
from mimesis import Generic
from mimesis import Datetime
from mimesis import Person
from data_generation.constants import *

class HarvestingData:

    def __init__(self):
        pass
    
    @staticmethod
    def random_date_between(start_date, end_date):
        delta = end_date - start_date
        random_days = random.randint(0, delta.days)
        return (start_date + timedelta(days=random_days)).date()

    @staticmethod
    def harvesting_cte(ftl_item, farm, next_entity, field_name_list = field_name_list, container_name_list=container_name_list):
        #Determine date
        start_date = datetime.strptime('2023-06-01', '%Y-%m-%d')
        end_date = datetime.now()
        random_dt = Datetime()
        generic = Generic('en')
        date_harvested = str(HarvestingData.random_date_between(start_date, end_date))
        data_submitter = farm.businessName
        food_name = ftl_item.Food.values[0]
        quantity = random.randint(1, 1000)
        recipient = next_entity.businessName
        unit_of_measure = generic.random.choice(('kg', 'g', 'lbs', 'Dozen'))
        farm_name = farm.businessName
        phone_number = farm.primaryPhone
        

        #Contamination
        cont_int = random.randint(0,6000)
        if cont_int == 1:
            contamination = 1
        else:
            contamination = 0 

        text = Text()
        #Determine what field or container was used
        if ftl_item.Supply_Chain.values[0] == 'Farmed':
            field_name = random.choice(field_name_list) + ' ' + random.choice(string.ascii_uppercase) + str(random.randint(1,10))
            container = 'n/a'
        elif ftl_item.Supply_Chain.values[0] == 'Aquaculture':
            field_name = 'n/a'
            container = random.choice(container_name_list) + ' ' + str(random.randint(1,10))
        
        #Need to add location description of farm where it was harvested
        harvesting_info = {
            'dataSubmitter': data_submitter,
            'recipient' : recipient,
            'commodity': food_name,
            'quantity' : quantity,
            'unitOfMeasure' : unit_of_measure,
            'farmName' : farm_name,
            'fieldName' : field_name,
            'containerName' : container,
            'cteDate' : date_harvested,
            'phoneNumber' : phone_number,
            'contaminated' : contamination,  
            'gtin':farm.companyPrefix+'.'+str(random.randint(100000, 999999)),
            'sgln':farm.gln,
            'pgln':farm.gln,
            'eventID':farm.gln+'.'+str(random.randint(1000000, 9999999)),
            'parentID':''
        }

        return harvesting_info
