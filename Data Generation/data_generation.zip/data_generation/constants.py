ENTITY_TYPES = [
    'farm',
    'processor',
    'packaging',
    'grocery',
    'restaurant',
    'distributor',
    'wholesaler',
    'groceryNoTransform',
    'landBasedReceiver',
    'seafoodFarm'
]

field_name_list = ['Field',
              'Bed',
              'Acre',
              'Garden',
              'Grasslands',
              'Ranch',
              'Barn'
              ]

container_name_list = ['Pond',
                       'Pool',
                       'Tank',
                       'Cage']
