import time
import random
from datetime import datetime, timedelta
from data_generation.utils import generate_reference_document_type_number, generate_traceability_lot_code

class LandBasedReceiverData:

    def __init__(self):
        pass

    @staticmethod
    def random_date_between(start_date, end_date):
        delta = end_date - start_date
        random_days = random.randint(0, delta.days)
        return (start_date + timedelta(days=random_days)).date()

    def first_land_based_receiver_cte(ftl_item, facility):
        #Determine the dates of harvest and landing
        start_date = datetime.strptime('2023-06-01', '%Y-%m-%d')
        end_date = datetime.now()
        firstHarvestDate = LandBasedReceiverData.random_date_between(start_date, end_date)
        secondHarvestDate = firstHarvestDate + timedelta(days=random.randint(2,10))

        dateLanded = secondHarvestDate + timedelta(days=random.randint(1,3))

        dataSubmitter =facility.businessName

        #Determine Harvest Location
        secondLine = 'Major Fishing Area ' + str(random.randint(1,10))

        pacific_states = ['WA','OR','CA','HI','AK']

        if facility.state in pacific_states:
            ocean = 'Pacific'
        else:
            ocean ='Atlantic'

        thirdLine = random.choice(['Northern', 'Southern', 'Central']) + ' ' + ocean 

        harvestDateAndLocation = str(firstHarvestDate) + ' - ' + str(secondHarvestDate) + '\n' + secondLine + '\n' + thirdLine

        #Determine the quantity and unit of measure
        quantity = random.randint(20,1000)
        unitOfMeasure = random.choice(['kg', 'lb'])

        #Determine the traceability lot code
        tLotData = dataSubmitter + ftl_item.Food.values[0] + str(quantity)
        gtin = facility.companyPrefix+'.'+str(random.randint(100000, 999999))
        traceability_lot_code = generate_traceability_lot_code(facility.companyPrefix,gtin,tLotData,str(dateLanded))

        #Contamination
        contaminated = 0
        if random.randint(0,2000) == 1:
            contaminated = 1


        first_land_based_receiver_info = {
            'dataSubmitter':dataSubmitter,
            'traceabilityLotCode':traceability_lot_code,
            'productDescription':ftl_item.Food.values[0],
            'quantity':quantity,
            'unitOfMeasure':unitOfMeasure,
            'harvestDateAndLocation':harvestDateAndLocation,
            'traceabilityLotCodeSourceLocation':facility.gln,
            'cteDate':str(dateLanded),
            'referenceDocumentTypeNumber': generate_reference_document_type_number(facility,'LANDING'),
            'contaminated':contaminated,
            'gtin':gtin,
            'sgln':facility.gln,
            'pgln':facility.gln,
            'eventID':facility.gln+'.'+str(random.randint(1000000, 9999999)),
            'parentID':''
        }

        return first_land_based_receiver_info
