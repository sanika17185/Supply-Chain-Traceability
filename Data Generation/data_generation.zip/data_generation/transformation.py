import time
import random
from datetime import datetime, timedelta
from data_generation.utils import generate_reference_document_type_number, generate_traceability_lot_code


class TransformationData:

    def __init__(self):
        pass

    @staticmethod
    def random_date_between(start_date, end_date):
        delta = end_date - start_date
        random_days = random.randint(0, delta.days)
        return (start_date + timedelta(days=random_days)).date()

    def transformation_cte(previous_cte, ftl_item, facility):
        
        #creating universal variables
        quantity = random.randint(1,1000)
        quantityUsed = random.randint(quantity,2000)
        unitOfMeasure = random.choice([ 'oz', 'lbs', 'kg'])
        dataSubmitter = facility.businessName
        tLotData = dataSubmitter + ftl_item.Food.values[0] + str(quantity)
        
        #generating transformation date and lot codes - this is dependent on whether there was a previous cte or not
        try: 
            transformedDate = str((datetime.strptime(previous_cte['cteDate'], '%Y-%m-%d') + timedelta(days=random.randint(0,3))).date())
            newGtin = facility.companyPrefix+'.'+str(random.randint(100000, 999999))
            traceabilityLotCode = generate_traceability_lot_code(facility.companyPrefix,newGtin,tLotData,transformedDate)
            oldTraceabilityLotCode = previous_cte['traceabilityLotCode']
            oldProductDescription = previous_cte['productDescription']
            previousUnitOfMeasure = previous_cte['unitOfMeasure']
            oldGtin = previous_cte['gtin']
            sgln = previous_cte['pgln']
            eventID = facility.gln+'.'+str(random.randint(1000000, 9999999))
            parentID = previous_cte['eventID']

            
        except:
            start_date = datetime.strptime('06/01/2023', '%m/%d/%Y')
            end_date = datetime.now()
            transformedDate = str(TransformationData.random_date_between(start_date, end_date))
            oldProductDescription = ''
            #oldtLotData = dataSubmitter + ftl_item.Food.values[0] + str(random.randint(3000,10000))
            #oldCompanyPrefix = f"{random.choice(['06','07','08','09','10','11','12','13'])}{random.randint(10000, 99999)}"
            #oldTraceabilityLotCode = generate_traceability_lot_code(oldCompanyPrefix,oldGt,oldtLotData,start_date)
            oldTraceabilityLotCode = ''
            newGtin = facility.companyPrefix+'.'+str(random.randint(100000, 999999))
            traceabilityLotCode = generate_traceability_lot_code(facility.companyPrefix,newGtin,tLotData,transformedDate)
            previousUnitOfMeasure = random.choice([ 'oz', 'lbs', 'kg'])
            oldGtin = ''
            sgln = facility.gln
            eventID = facility.gln+'.'+str(random.randint(1000000, 9999999))
            parentID = ''
        
        #transforming foods
        #fruit
        if ftl_item.Category.values[0] == 'Fruit': 
            shortDescription = "Fresh Cut " + ftl_item.Food.values[0]
        elif ftl_item.Category.values[0] == 'Melons': 
            shortDescription = "Fresh Cut " + ftl_item.Food.values[0]
        elif ftl_item.Category.values[0] == 'Tropical Tree Fruits': 
            shortDescription = "Fresh Cut " + ftl_item.Food.values[0]
        
        #nut butter
        elif ftl_item.Category.values[0] == 'Nut Butter':
            shortDescription = ftl_item.Food.values[0] + " Butter"
    
        #salads
        elif ftl_item.Category.values[0] == 'Shell Eggs':
            shortDescription = "Egg Salad"
        elif ftl_item.Category.values[0] == 'Crustaceans': 
            shortDescription = "Seafood Salad"
        elif ftl_item.Category.values[0] == 'Leafy greens (fresh)': 
            shortDescription = "Pasta Salad"
        elif ftl_item.Category.values[0] == 'Peppers': 
            shortDescription = "Pasta Salad"
        elif ftl_item.Category.values[0] == 'Tomatoes': 
            shortDescription = "Pasta Salad"
        elif ftl_item.Category.values[0] == 'Cucumbers (fresh)': 
            shortDescription = "Pasta Salad"
        elif ftl_item.Category.values[0] == 'Herbs (fresh)': 
            shortDescription = random.choice(['Egg Salad','Potato Salad','Pasta Salad','Seafood Salad']) 
        
        #fish
        elif ftl_item.Category.values[0] == 'Seafood':
            if random.randint(0,100) < 15:
                shortDescription = "Smoked " + ftl_item.Food.values[0]
            else:
                shortDescription = ftl_item.Food.values[0] + " filet"
        
        #remaining foods
        else:
            shortDescription = ''
        
        #generates product description dependent on whether food has been transformed previously 
        if shortDescription != '' :
            productDescription = facility.businessName+ ' ' + shortDescription + ', ' +str(quantity) + unitOfMeasure + ' case'
        else:
            productDescription = facility.businessName+ ' ' + ftl_item.Food.values[0] + ', ' +str(quantity) + unitOfMeasure + ' case'
        
        #Contamination
        try:
            contaminated = previous_cte['contaminated']
        except:
            contaminated = 0

        if contaminated == 0:
            if random.randint(0,6000) == 1:
                contaminated = 1

        bizTransactionType = random.choice(['TRF','TE','ADJUSTMENT'])
        
        transformation_info = {
            'dataSubmitter': dataSubmitter,
            'oldTraceabilityLotCode': oldTraceabilityLotCode,
            'oldProductDescription':oldProductDescription,
            'quantityUsed':quantityUsed,
            'previousUnitOfMeasure':previousUnitOfMeasure,
            'traceabilityLotCode': traceabilityLotCode,
            'traceabilityLotCodeSourceLocation': facility.gln,
            'cteDate': transformedDate,
            'productDescription': productDescription,
            'quantity': quantity,
            'unitOfMeasure': unitOfMeasure,
            'referenceDocumentTypeNumber': generate_reference_document_type_number(facility,bizTransactionType),
            'contaminated':contaminated,
            'inputGtin':oldGtin,
            'gtin':newGtin,
            'sgln':sgln,
            'pgln':facility.gln,
            'shortDescription':shortDescription,
            'eventID':eventID,
            'parentID':parentID
        }

        return transformation_info
