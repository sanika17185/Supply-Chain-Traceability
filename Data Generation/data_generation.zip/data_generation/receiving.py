import time
import random
from datetime import datetime, timedelta
from data_generation.utils import generate_reference_document_type_number


class ReceivingData:

    def __init__(self):
        pass

    @staticmethod
    def receiving_cte(previous_cte, facility):
        receivingDate = str((datetime.strptime(previous_cte['cteDate'], '%Y-%m-%d') + timedelta(days=random.randint(0,3))).date())

        contaminated = previous_cte['contaminated']
        bizTransactionType = random.choice(['BOL','RECADV','RECEIPT','RCV'])
        

        if contaminated == 0:
            if random.randint(0,6000) == 1:
                contaminated = 1

        receiving_info = {
            'dataSubmitter': facility.businessName,
            'traceabilityLotCode': previous_cte['traceabilityLotCode'],
            'quantity': previous_cte['quantity'],
            'unitOfMeasure':previous_cte['unitOfMeasure'],
            'productDescription': previous_cte['productDescription'],
            'previousSourceLocation': previous_cte['dataSubmitter'],
            'receivingLocation': facility.businessName,
            'cteDate': receivingDate,
            'traceabilityLotCodeSourceLocation': previous_cte['traceabilityLotCodeSourceLocation'],
            'referenceDocumentTypeNumber': generate_reference_document_type_number(facility,bizTransactionType),
            'contaminated':contaminated,
            'gtin':previous_cte['gtin'],
            'sgln':previous_cte['pgln'],
            'pgln':facility.gln,
            'eventID':facility.gln+'.'+str(random.randint(1000000, 9999999)),
            'parentID':previous_cte['eventID']
        }

        return receiving_info
