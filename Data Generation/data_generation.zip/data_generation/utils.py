import random
import hashlib
import pandas as pd
from datetime import datetime, timedelta

def generate_farm_name():
    adjectives = ['Green', 'Sunny', 'Golden', 'Misty', 'Whispering', 'Breezy', 'Happy', 'Lucky', 'Peaceful']
    nouns = ['Meadows', 'Fields', 'Grove', 'Acres', 'Hills', 'Harvest', 'Valley', 'Orchard', 'Pastures']

    adjective = random.choice(adjectives)
    noun = random.choice(nouns)

    farm_name = adjective + ' ' + noun + ' Farm'
    return farm_name

def generate_wholesaler_name():
    prefixes = ['Fresh', 'Prime', 'Select', 'Quality', 'Premium', 'Global', 'Gourmet', 'Best', 'Top', 'Wholesome']
    suffixes = ['Foods', 'Provisions', 'Supplies', 'Distributors', 'Wholesale', 'Imports', 'Market', 'Trading', 'Traders']

    prefix = random.choice(prefixes)
    suffix = random.choice(suffixes)

    wholesaler_name = prefix + ' ' + suffix
    return wholesaler_name

def generate_grocery_name():
    prefixes = ['Fresh', 'Healthy', 'Natural', 'Gourmet', 'Tasty', 'Delicious', 'Organic', 'Wholesome', 'Premium', 'Fine']
    suffixes = ['Foods', 'Market', 'Grocery', 'Mart', 'Shop', 'Store', 'Bazaar', 'Corner', 'Emporium', 'Outlet']

    prefix = random.choice(prefixes)
    suffix = random.choice(suffixes)

    retailer_name = prefix + ' ' + suffix
    return retailer_name

def generate_distributor_name():
    prefixes = ['Global', 'International', 'Premium', 'Quality', 'Reliable', 'Prime', 'Gourmet', 'Fine', 'Superior', 'Trusted']
    suffixes = ['Distributors', 'Distribution', 'Imports', 'Supply', 'Logistics', 'Wholesalers', 'Trade', 'Services', 'Exim', 'Network']

    prefix = random.choice(prefixes)
    suffix = random.choice(suffixes)

    distributor_name = prefix + ' ' + suffix
    return distributor_name

def generate_packaging_company_name():
    prefixes = ['Eco', 'Green', 'Fresh', 'Quality', 'Premium', 'Global', 'Innovative', 'Advanced', 'Bio', 'Secure']
    suffixes = ['Pack', 'Packaging', 'Packs', 'Solutions', 'Wraps', 'Containers', 'Seal', 'Wrap', 'Encase', 'Box']

    prefix = random.choice(prefixes)
    suffix = random.choice(suffixes)

    packaging_company_name = prefix + ' ' + suffix
    return packaging_company_name

def generate_restaurant_name():
    adjectives = ['Delicious', 'Tasty', 'Savory', 'Gourmet', 'Exquisite', 'Flavorful', 'Authentic', 'Fusion', 'Charming', 'Cozy']
    nouns = ['Bistro', 'Cuisine', 'Grill', 'Eatery', 'Cafe', 'Brasserie', 'Diner', 'Tavern', 'Kitchen', 'Restaurant']

    adjective = random.choice(adjectives)
    noun = random.choice(nouns)

    restaurant_name = adjective + ' ' + noun
    return restaurant_name

def generate_food_processing_company_name():
    prefixes = ['Fresh', 'Natural', 'Pure', 'Premium', 'Quality', 'Global', 'Innovative', 'Healthy', 'Organic', 'Wholesome']
    suffixes = ['Foods', 'Processing', 'Kitchen', 'Cuisine', 'Provisions', 'Solutions', 'Manufacturing', 'Products', 'Industries', 'Operations']

    prefix = random.choice(prefixes)
    suffix = random.choice(suffixes)

    company_name = prefix + ' ' + suffix
    return company_name

def generate_land_based_receiver_company_name():
    prefixes = ['Ocean', 'Sea', 'Marine', 'Coastal', 'Aqua', 'Wave', 'Deep', 'Harbor', 'Fresh', 'Tidal']
    suffixes = ['Seafoods', 'Fisheries', 'Maritime', 'Catches', 'Coast', 'Aquatics', 'Mariscos', 'Delights', 'Bay', 'Catchers']

    prefix = random.choice(prefixes)
    suffix = random.choice(suffixes)

    company_name = prefix + ' ' + suffix
    return company_name

def generate_fish_farm_name():
    prefixes = ["Ocean", "Aqua", "Marine", "Sea", "Blue", "Nautical"]
    suffixes = ["Fish Farm", "Aquafarm", "Fishery", "Aquaculture", "Fish Haven"]

    prefix = random.choice(prefixes)
    suffix = random.choice(suffixes)

    company_name = prefix + ' ' + suffix
    return company_name


BUSINESS_NAME_MAPPING = {
    'farm':generate_farm_name,
    'wholesaler':generate_wholesaler_name,
    'grocery':generate_grocery_name,
    'groceryNoTransform':generate_grocery_name,
    'distributor':generate_distributor_name,
    'packaging':generate_packaging_company_name,
    'restaurant':generate_restaurant_name,
    'processor':generate_food_processing_company_name,
    'landBasedReceiver':generate_land_based_receiver_company_name,
    'seafoodFarm':generate_fish_farm_name
}

def fetch_business_name(business_type):
    business_name = BUSINESS_NAME_MAPPING[business_type]()
    return business_name


def generate_traceability_lot_code(companyPrefix, gtin, tLotData, timestamp):
    hash_input = f"{tLotData}{timestamp}"
    hash_value = hashlib.sha1(hash_input.encode()).hexdigest()
    lot_code = f"urn:epc:class:lgtin:{companyPrefix}.{gtin.split('.')[1]}.{hash_value[:17]}"
    return lot_code

def generate_reference_document_type_number(facility,event):
    reference_type_number = f"urn:epcglobal:epcis:{event}.{facility.companyPrefix}"
    return reference_type_number


#Cross contaminate function
def cross_contaminate(dfs):
    cross_contamination_probability = random.choice([3,5,8])
    later_ctes = [
        'shipping',
        'receiving'
    ]

    for i in dfs['transformation'][dfs['transformation'].contaminated == 1].index:

        row = dfs['transformation'].iloc[i]
        facility = row.pgln

        #Determine dates of possible contamination
        try:
            start_date = datetime.strptime(str(row.cteDate),'%Y-%m-%d')
        except:
            start_date = row.cteDate
        try:
            end_date = datetime.strptime(dfs['shipping'][dfs['shipping'].traceabilityLotCode == row.traceabilityLotCode].cteDate)
        except:
            end_date = start_date + timedelta(days=3)

        #Filter the data for rows that were possibly impacted by the contamination
        filterData = dfs['transformation']
        filterData['cteDate'] = pd.to_datetime(filterData['cteDate'])
        impacted = filterData[(filterData.pgln == facility)&(filterData.cteDate >= start_date)&(filterData.cteDate <= end_date)]
        if len(impacted) > 0:

            #Determine if it will spread to the node or not
            infected = []
            infectedLots = []
            for record in impacted.index:
                if random.randint(0,10) < cross_contamination_probability:
                    infectedGroup = [record]
                    infectedLot = impacted.loc[record].traceabilityLotCode
                    infectedLots.append(infectedLot)
                    infectedGroup.extend(filterData[filterData.oldTraceabilityLotCode == infectedLot].index)
                    infected.extend(list(set(infectedGroup)))

            #Spread the infection to the rows
            dfs['transformation'].loc[infected,'contaminated'] = 1

            #Spread the infection to every row in all other CTEs that were impacted
            for cte in later_ctes:
                dfs[cte].loc[dfs[cte][dfs[cte].traceabilityLotCode.isin(infectedLots)].index,'contaminated'] = 1
    return dfs

#Add EPCIS Formatting to fields that lacked it previously
def add_epcis_formatting(cte_data):
    for name in list(cte_data.keys()):
        cte_data[name]['gtin'] = 'urn:epc:idpat:sgtin:' + cte_data[name]['gtin']
        cte_data[name]['sgln'] = 'urn:epc:id:sgln:' + cte_data[name]['sgln']
        cte_data[name] ['pgln'] = 'urn:epc:id:pgln:' + cte_data[name]['pgln']
    return cte_data

