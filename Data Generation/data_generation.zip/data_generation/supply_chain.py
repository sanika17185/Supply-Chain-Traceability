import random

class SupplyChain:
    def __init__(self):
        pass
    
    @staticmethod
    def generate_supply_chain(ftl_item):
        #Initialize the supply chain variables
        chain = []

        farm = 'farm'
        field_packed = 'fieldPacked'
        packaging_processor = 'packaging'
        food_processor = 'processor'
        kill = 'stop'
        lbr = 'landBasedReceiver'
        direct_sale = 'directToConsumer'
        seaFarm = 'seafoodFarm'
        agg = 'aggregator'
        rest = 'restaurant'
        grocNoFood = 'groceryNoTransform'
        grocFood = 'grocery'
        dist = 'distributor'
        whole = 'wholesaler'


        #Determine if the food will be an empty node item - do this after Zac sends the rest of the supply chain info

        #Farmed Product Supply Chain Route
        if ftl_item.Supply_Chain.values[0] == 'Farmed':
            chain.append(farm)
            #Determine if field packed or processed
            pack_int = random.randint(0,100)
            if pack_int >= 50:
                chain.append(field_packed)
            else:
                chain.append(packaging_processor)

        #Created Product Supply Chain Route
        elif ftl_item.Supply_Chain.values[0] == 'Created':
            chain.append(food_processor)
            if ftl_item.Category.values[0] == 'Cheese' or ftl_item.Category.values[0] == 'Nut Butters':
                rand = random.randint(0,100)
                if rand > 50:
                    chain.append(food_processor)
                #Determine Cheese Continued Manufacturing Route
                if ftl_item.Category.values[0] == 'Nut Butters':
                    if rand > 75:
                        chain.append(food_processor)
                    else:
                        chain.append(kill)
                else:
                    chain.append(kill)

        #Fish Supply Chain Route
        elif ftl_item.Category.values[0] == 'Seafood':

            #Caught fish Supply Chain Route
            if ftl_item.Supply_Chain.values[0] == 'Caught':
                chain.append(lbr)
                #Fill in the rest here

            #Aquaculture Supply Chain Route
            if ftl_item.Supply_Chain.values[0] == 'Aquaculture':
                chain.append(seaFarm)

            #Determine if the food will go to an aggregator
            rand = random.randint(0,100)
            if rand > 50:
                chain.append(agg)

            #Determine if the food goes through a kill step or continues to get processed
            chain.append(food_processor)

            rand = random.randint(0,100)
            if rand > 50:
                chain.append(food_processor)

                if rand > 75:
                    chain.append(food_processor)

                else:
                    chain.append(kill)

            else:
                chain.append(kill)

                
        if chain[-1] != kill:
            #Initialize the retail options
            retail_options = [rest, grocFood, grocNoFood]
            
            #Sale Route - this will be the same for every food
            sale_int = random.randint(0,100)
            #Determine if it is sold direct-to-consumer
            if sale_int <= 7:
                sale_int = random.randint(0,100)
                if sale_int <= 27:
                    chain.append(direct_sale)
                else:
                    chain.append(random.choice(retail_options))
            else:
            
                #If not, do the indirect sales route
                route_1 = random.randint(0,100)
                if route_1 <= 50:
                    chain.append(dist)
                    route_2 = random.randint(0,100)
                    if route_2 <= 20:
                        chain.append(whole)
                    else:
                        chain.append(random.choice(retail_options))
                    
                else:
                    chain.append(food_processor)
                    route_2 = random.randint(0,100)
                    if route_2 <= 50:
                        chain.append(dist)
                        route_2 = random.randint(0,100)
                        if route_2 <= 20:
                            chain.append(whole)
                        else:
                            chain.append(random.choice(retail_options))
                    else:
                        route_2 = random.randint(0,100)
                        if route_2 <= 20:
                            chain.append(whole)
                        else:
                            chain.append(random.choice(retail_options))
                if chain[-1] == whole:
                    route_int = random.randint(0,100)
                    if route_int < 50:
                        chain.append(random.choice(retail_options))
        print(chain)
        return chain
