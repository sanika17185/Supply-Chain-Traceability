import time
import random
from mimesis import Generic
from datetime import datetime, timedelta
from data_generation.utils import generate_reference_document_type_number, generate_traceability_lot_code


class PackagingData:

    def __init__(self):
        pass
    
    @staticmethod
    def packaging_cte(harvesting_info, cooling_info, ftl_item, facility):
        # List of packaging types
        packaging_type = ['Box', 'Bag', 'Crate', 'Can', 'Bottle', 'Jar', 'Pouch', 'Carton']
        generic = Generic('en')
        data_submitter = facility.businessName
        package_type = random.choice(packaging_type)
        quantity = random.randint(1, 1000)
        unit_of_measure = generic.random.choice(('kg', 'g', 'lbs', 'Dozen'))
        packaging_date = str((datetime.strptime(cooling_info['cteDate'], '%Y-%m-%d') + timedelta(days=random.randint(0,3))).date())
        tLotData = data_submitter + ftl_item.Food.values[0] + str(quantity)
        traceability_lot_code = generate_traceability_lot_code(facility.companyPrefix,cooling_info['gtin'],tLotData,packaging_date)
        product_description = harvesting_info['dataSubmitter'] + ' ' + harvesting_info['commodity'] + ', ' + str(random.randint(1, 50)) + unit_of_measure + ' case'
        contaminated = cooling_info['contaminated']

        if contaminated == 0:
            if random.randint(0,6000) == 1:
                contaminated = 1


        packaging_info = {
            'dataSubmitter': data_submitter,
            'commodity':ftl_item.Food.values[0],
            'dateFoodReceived' : packaging_date,
            'quantityReceived':harvesting_info['quantity'],
            'harvestingLocation':harvesting_info['dataSubmitter'],
            'harvestedField':harvesting_info['fieldName'], #For produce
            'harvestedContainer':harvesting_info['containerName'], #For Aquaculture
            'harvestedPhoneNumber':harvesting_info['phoneNumber'],
            'dateHarvested':harvesting_info['cteDate'],
            'coolingLocation':cooling_info['dataSubmitter'],
            'dateOfCooling':cooling_info['cteDate'],
            'traceabilityLotCode': traceability_lot_code,
            'productDescription':product_description,
            'quantity' : quantity,
            'unitOfMeasure':cooling_info['unitOfMeasure'],
            'packageType': package_type,
            'traceabilityLotCodeSourceLocation':facility.gln,
            'cteDate' : packaging_date,
            'referenceDocumentTypeNumber': generate_reference_document_type_number(facility,'IP WO'),
            'contaminated':contaminated,
            'gtin':cooling_info['gtin'],
            'sgln':cooling_info['pgln'],
            'pgln':facility.gln,
            'eventID':facility.gln+'.'+str(random.randint(1000000, 9999999)),
            'parentID':cooling_info['eventID']
        }

        return packaging_info
